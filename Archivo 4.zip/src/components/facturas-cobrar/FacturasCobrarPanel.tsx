import { useEffect, useMemo, useState } from "react";
import type { ReactNode } from "react";
import {
  Archive,
 
  ChevronDown,
  ChevronsUpDown,
  Eye,
  Plus,
  ReceiptText,
  RefreshCcw,
  Search,
  ShieldCheck,
  Wallet,
  X
} from "lucide-react";
import {
  useFacturasCobrarStore,
  type CobroDraft,
  type DocumentoDraft,
  type FacturaCobrar,
  type FacturasGrupoMoneda,
  type FacturasGrupoSucursal,
  type FacturasTab
} from "../../store/facturasCobrarStore";
import { IconButton } from "../ui/IconButton";
import { formatMoneyAR } from "../../lib/formatters";

type SelectOption = {
  value: string;
  label: string;
};

type ToastState = {
  type: "success" | "error";
  message: string;
} | null;

const MONTH_NAMES = [
  "Enero",
  "Febrero",
  "Marzo",
  "Abril",
  "Mayo",
  "Junio",
  "Julio",
  "Agosto",
  "Septiembre",
  "Octubre",
  "Noviembre",
  "Diciembre"
];

const MONEDA_OPTIONS: SelectOption[] = [
  { value: "todos", label: "Todas" },
  { value: "ARS", label: "Pesos" },
  { value: "USD", label: "Dólares" }
];

const MONEDA_DRAFT_OPTIONS: SelectOption[] = [
  { value: "ARS", label: "Pesos" },
  { value: "USD", label: "Dólares" }
];

const TIPO_DOCUMENTO_OPTIONS: SelectOption[] = [
  { value: "todos", label: "Todos" },
  { value: "FACTURA", label: "Factura" },
  { value: "POSTVENTA", label: "Postventa" },
  { value: "NOTA_CREDITO", label: "Nota crédito" },
  { value: "NOTA_DEBITO", label: "Nota débito" }
];

const TIPO_DOCUMENTO_DRAFT_OPTIONS: SelectOption[] = [
  { value: "FACTURA", label: "Factura carritos" },
  { value: "POSTVENTA", label: "Postventa" },
  { value: "NOTA_CREDITO", label: "Nota crédito" },
  { value: "NOTA_DEBITO", label: "Nota débito" }
];

const ESTADO_OPTIONS: SelectOption[] = [
  { value: "todos", label: "Todos" },
  { value: "PENDIENTE", label: "Pendientes" },
  { value: "COBRADA", label: "Cobradas" }
];

const FORMA_COBRO_OPTIONS: SelectOption[] = [
  { value: "TRANSFERENCIA", label: "Transferencia / Banco" },
  { value: "CASHFLOW", label: "Cashflow" }
];

function getToday(): string {
  const now = new Date();
  const argentinaNow = new Date(now.toLocaleString("en-US", { timeZone: "America/Argentina/Cordoba" }));
  const year = argentinaNow.getFullYear();
  const month = String(argentinaNow.getMonth() + 1).padStart(2, "0");
  const day = String(argentinaNow.getDate()).padStart(2, "0");

  return `${year}-${month}-${day}`;
}

function formatDateAR(value?: string | null): string {
  if (!value) return "—";

  const clean = value.slice(0, 10);
  const [year, month, day] = clean.split("-");

  if (!year || !month || !day) return "—";

  return `${day}/${month}/${year}`;
}

function parseMoney(value: string | number | null | undefined): number {
  if (typeof value === "number") return Number.isFinite(value) ? value : 0;

  const normalized = String(value || "")
    .replace(/\./g, "")
    .replace(",", ".")
    .replace(/[^\d.-]/g, "");

  const parsed = Number(normalized);
  return Number.isFinite(parsed) ? parsed : 0;
}

function maskDocumentoNumero(value: string): string {
  const clean = value.trim();

  if (clean.includes("/") || clean.includes("-")) {
    return clean.slice(0, 24);
  }

  const digits = clean.replace(/\D/g, "").slice(0, 12);

  if (digits.length <= 4) return digits;

  return `${digits.slice(0, 4)}-${digits.slice(4)}`;
}

function getInitials(name: string): string {
  return name
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part.slice(0, 1).toUpperCase())
    .join("");
}

function getTipoLabel(tipo: string): string {
  const labels: Record<string, string> = {
    FACTURA: "Factura",
    POSTVENTA: "Postventa",
    NOTA_CREDITO: "Nota crédito",
    NOTA_DEBITO: "Nota débito"
  };

  return labels[tipo] || tipo;
}

function getMonthName(value?: number | null): string {
  if (!value || value < 1 || value > 12) return "—";
  return MONTH_NAMES[value - 1];
}

function getMonthYearLabel(mes: number, anio: number): string {
  return `${MONTH_NAMES[mes - 1] || "Mes"} ${anio}`;
}

function FieldLabel({ children }: { children: ReactNode }) {
  return (
    <label className="mb-1.5 block text-[10px] font-black uppercase tracking-[0.14em] text-[#64748b]">
      {children}
    </label>
  );
}

function TextInput({
  value,
  onChange,
  placeholder,
  inputMode = "text"
}: {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  inputMode?: React.HTMLAttributes<HTMLInputElement>["inputMode"];
}) {
  return (
    <input
      value={value}
      onChange={(event) => onChange(event.target.value)}
      placeholder={placeholder}
      inputMode={inputMode}
      className="h-9 w-full rounded-xl border border-black/10 bg-[#f8fafc] px-3 text-xs font-semibold text-[#111827] outline-none transition focus:border-nostur-orange"
    />
  );
}

function TextArea({
  value,
  onChange,
  placeholder
}: {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
}) {
  return (
    <textarea
      value={value}
      onChange={(event) => onChange(event.target.value)}
      placeholder={placeholder}
      className="min-h-[82px] w-full resize-none rounded-xl border border-black/10 bg-white px-3 py-2 text-xs font-semibold text-[#111827] outline-none transition focus:border-nostur-orange"
    />
  );
}

function NosturSelect({
  value,
  onChange,
  options,
  placeholder = "Seleccionar"
}: {
  value: string;
  onChange: (value: string) => void;
  options: SelectOption[];
  placeholder?: string;
}) {
  const [open, setOpen] = useState(false);
  const selected = options.find((option) => option.value === value);

  return (
    <div className={["relative", open ? "z-[150]" : "z-0"].join(" ")}>
      <button
        type="button"
        onClick={() => setOpen((current) => !current)}
        className="flex h-9 w-full items-center justify-between gap-2 rounded-xl border border-black/10 bg-[#f8fafc] px-3 text-left text-xs font-semibold text-[#111827] outline-none transition hover:bg-white"
      >
        <span className={selected ? "truncate" : "truncate text-[#94a3b8]"}>
          {selected?.label || placeholder}
        </span>
        <ChevronDown
          size={14}
          strokeWidth={1.8}
          className={["shrink-0 text-[#64748b] transition", open ? "rotate-180" : ""].join(" ")}
        />
      </button>

      {open ? (
        <>
          <button
            type="button"
            className="fixed inset-0 z-[140] cursor-default bg-transparent"
            onClick={() => setOpen(false)}
            tabIndex={-1}
          />

          <div className="absolute left-0 right-0 top-[42px] z-[160] max-h-56 overflow-auto rounded-2xl border border-black/10 bg-white p-1 shadow-xl">
            {options.length === 0 ? (
              <div className="px-3 py-2 text-xs font-bold text-[#94a3b8]">Sin opciones</div>
            ) : (
              options.map((option) => {
                const active = option.value === value;

                return (
                  <button
                    key={option.value}
                    type="button"
                    onClick={() => {
                      onChange(option.value);
                      setOpen(false);
                    }}
                    className={[
                      "flex h-8 w-full items-center rounded-xl px-3 text-left text-xs font-bold transition",
                      active ? "bg-nostur-orange text-white" : "text-[#334155] hover:bg-[#f1f5f9]"
                    ].join(" ")}
                  >
                    <span className="truncate">{option.label}</span>
                  </button>
                );
              })
            )}
          </div>
        </>
      ) : null}
    </div>
  );
}

function StatusBadge({
  children,
  type
}: {
  children: ReactNode;
  type: "ok" | "pending" | "danger" | "neutral";
}) {
  const className = {
    ok: "border-green-200 bg-green-50 text-green-700",
    pending: "border-amber-200 bg-amber-50 text-amber-700",
    danger: "border-red-200 bg-red-50 text-red-700",
    neutral: "border-black/10 bg-white text-[#334155]"
  }[type];

  return (
    <span className={["rounded-xl border px-2.5 py-1 text-[10px] font-black uppercase tracking-wide", className].join(" ")}>
      {children}
    </span>
  );
}

function Toast({ toast, onClose }: { toast: ToastState; onClose: () => void }) {
  if (!toast) return null;

  return (
    <div className="fixed right-5 top-5 z-[260] w-[320px] rounded-2xl border border-black/10 bg-white p-4 text-xs shadow-2xl">
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className={["mb-1 font-black", toast.type === "success" ? "text-green-700" : "text-red-700"].join(" ")}>
            {toast.type === "success" ? "Operación exitosa" : "Atención"}
          </div>
          <div className="font-semibold text-[#334155]">{toast.message}</div>
        </div>

        <button
          type="button"
          onClick={onClose}
          className="flex h-7 w-7 shrink-0 items-center justify-center rounded-xl text-[#64748b] hover:bg-[#f1f5f9] hover:text-[#111827]"
        >
          <X size={14} />
        </button>
      </div>
    </div>
  );
}

function createInitialDocumentDraft(): DocumentoDraft {
  const today = getToday();

  return {
    tipo_documento: "FACTURA",
    numero_documento: "",
    razon_social: "ALMUNDO.COM",
    moneda: "ARS",
    sucursal_id: "",
    mes: today.slice(5, 7),
    anio: today.slice(0, 4),
    neto_gravado: "",
    observaciones: "",
    selectedCarritoIds: []
  };
}

function createInitialCobroDraft(total = 0): CobroDraft {
  return {
    forma_cobro: "TRANSFERENCIA",
    caja_id: "",
    importe_ingresado_banco: total > 0 ? String(total.toFixed(2)).replace(".", ",") : "",
    referencia_cobro: "",
    observaciones: ""
  };
}

function DocumentoModal({
  onClose,
  onSaved
}: {
  onClose: () => void;
  onSaved: () => void;
}) {
  const saving = useFacturasCobrarStore((state) => state.saving);
  const catalogos = useFacturasCobrarStore((state) => state.catalogos);
  const createDocumento = useFacturasCobrarStore((state) => state.createDocumento);
  const getCarritosDisponiblesForDraft = useFacturasCobrarStore((state) => state.getCarritosDisponiblesForDraft);

  const [draft, setDraft] = useState<DocumentoDraft>(() => createInitialDocumentDraft());

  const sucursalOptions: SelectOption[] = catalogos.sucursales.map((item) => ({
    value: item.id,
    label: item.nombre
  }));

  useEffect(() => {
    if (draft.sucursal_id || catalogos.sucursales.length === 0) return;

    const barrioJardin = catalogos.sucursales.find((item) => {
      const nombre = item.nombre.toLowerCase();
      return nombre.includes("barrio jardín") || nombre.includes("barrio jardin");
    });

    const defaultSucursal = barrioJardin || catalogos.sucursales[0];

    if (defaultSucursal?.id) {
      setDraft((current) => ({
        ...current,
        sucursal_id: defaultSucursal.id
      }));
    }
  }, [catalogos.sucursales, draft.sucursal_id]);

  const carritosDisponibles = getCarritosDisponiblesForDraft(draft);
  const selectedCarritos = carritosDisponibles.filter((carrito) => draft.selectedCarritoIds.includes(carrito.id));

  const facturaCarritosTotal = selectedCarritos.reduce((total, carrito) => {
    const control = carrito.carritos_control?.[0];
    return total + parseMoney(control?.importe_a_facturar);
  }, 0);

  const inputNeto = parseMoney(draft.neto_gravado);
  const inputIva = inputNeto * 0.21;
  const inputTotal = inputNeto + inputIva;
  const isFacturaCarritos = draft.tipo_documento === "FACTURA";

  function setField<K extends keyof DocumentoDraft>(key: K, value: DocumentoDraft[K]) {
    setDraft((current) => ({ ...current, [key]: value }));
  }

  async function submit() {
    const ok = await createDocumento(draft);
    if (ok) onSaved();
  }

  return (
    <div className="fixed inset-0 z-[220] flex items-start justify-center bg-black/25 px-4 pt-8 backdrop-blur-sm">
      <div className="max-h-[calc(100vh-56px)] w-full max-w-6xl overflow-auto rounded-[24px] border border-black/10 bg-white p-5 text-[#1f2937] shadow-2xl">
        <div className="mb-4 flex items-start justify-between gap-3">
          <div>
            <h2 className="text-lg font-black text-[#111827]">Nuevo documento a cobrar</h2>
            <p className="text-xs text-[#64748b]">
              Facturas, postventa, notas de crédito y notas de débito para Almundo.
            </p>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="flex h-9 w-9 items-center justify-center rounded-xl text-[#64748b] hover:bg-black/5 hover:text-[#111827]"
          >
            <X size={17} />
          </button>
        </div>

        <div className="grid gap-4 xl:grid-cols-[minmax(0,1fr)_300px]">
          <main className="rounded-[24px] border border-black/10 bg-white p-4">
            <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
              <div>
                <FieldLabel>Tipo documento</FieldLabel>
                <NosturSelect
                  value={draft.tipo_documento}
                  onChange={(value) =>
                    setDraft((current) => ({
                      ...current,
                      tipo_documento: value as DocumentoDraft["tipo_documento"],
                      selectedCarritoIds: []
                    }))
                  }
                  options={TIPO_DOCUMENTO_DRAFT_OPTIONS}
                />
              </div>

              <div>
                <FieldLabel>Número</FieldLabel>
                <TextInput
                  value={draft.numero_documento}
                  onChange={(value) => setField("numero_documento", maskDocumentoNumero(value))}
                  placeholder="0001-0000000"
                  inputMode="numeric"
                />
              </div>

              <div>
                <FieldLabel>A quién se factura</FieldLabel>
                <TextInput
                  value={draft.razon_social}
                  onChange={(value) => setField("razon_social", value)}
                  placeholder="ALMUNDO.COM"
                />
              </div>

              <div>
                <FieldLabel>Moneda</FieldLabel>
                <NosturSelect
                  value={draft.moneda}
                  onChange={(value) =>
                    setDraft((current) => ({
                      ...current,
                      moneda: value as DocumentoDraft["moneda"],
                      selectedCarritoIds: []
                    }))
                  }
                  options={MONEDA_DRAFT_OPTIONS}
                />
              </div>

              <div>
                <FieldLabel>Sucursal</FieldLabel>
                <NosturSelect
                  value={draft.sucursal_id}
                  onChange={(value) =>
                    setDraft((current) => ({
                      ...current,
                      sucursal_id: value,
                      selectedCarritoIds: []
                    }))
                  }
                  options={sucursalOptions}
                  placeholder="Seleccionar sucursal"
                />
              </div>

              {!isFacturaCarritos ? (
                <>
                  <div>
                    <FieldLabel>Mes</FieldLabel>
                    <NosturSelect
                      value={draft.mes}
                      onChange={(value) => setField("mes", value)}
                      options={MONTH_NAMES.map((month, index) => ({
                        value: String(index + 1).padStart(2, "0"),
                        label: month
                      }))}
                    />
                  </div>

                  <div>
                    <FieldLabel>Año</FieldLabel>
                    <TextInput
                      value={draft.anio}
                      onChange={(value) => setField("anio", value.replace(/\D/g, "").slice(0, 4))}
                      placeholder="2026"
                      inputMode="numeric"
                    />
                  </div>

                  <div>
                    <FieldLabel>Importe sin IVA</FieldLabel>
                    <TextInput
                      value={draft.neto_gravado}
                      onChange={(value) => setField("neto_gravado", value)}
                      placeholder="0,00"
                      inputMode="decimal"
                    />
                  </div>
                </>
              ) : null}

              <div className="md:col-span-2 xl:col-span-4">
                <FieldLabel>Observaciones / motivo</FieldLabel>
                <TextArea
                  value={draft.observaciones}
                  onChange={(value) => setField("observaciones", value)}
                  placeholder="Motivo de nota, referencia de postventa o comentarios..."
                />
              </div>
            </div>

            {isFacturaCarritos ? (
              <div className="mt-4">
                <div className="mb-3 flex items-center justify-between gap-3">
                  <div>
                    <h3 className="text-sm font-black text-[#111827]">Carritos disponibles</h3>
                    <p className="text-[11px] text-[#64748b]">
                      Solo aparecen carritos controlados, no anulados y no facturados para la sucursal/moneda elegida.
                    </p>
                  </div>

                  <div className="rounded-2xl border border-nostur-orange/20 bg-nostur-orange/10 px-4 py-2 text-right">
                    <div className="text-[10px] font-black uppercase tracking-wide text-nostur-orange">
                      Total factura
                    </div>
                    <div className="text-sm font-black text-[#111827]">
                      {formatMoneyAR(facturaCarritosTotal, draft.moneda)}
                    </div>
                  </div>
                </div>

                <div className="grid gap-2">
                  {carritosDisponibles.length === 0 ? (
                    <div className="rounded-2xl border border-black/10 bg-[#f8fafc] p-5 text-center text-xs text-[#64748b]">
                      No hay carritos disponibles para esta sucursal y moneda.
                    </div>
                  ) : (
                    carritosDisponibles.map((carrito) => {
                      const control = carrito.carritos_control?.[0];
                      const checked = draft.selectedCarritoIds.includes(carrito.id);

                      return (
                        <button
                          key={carrito.id}
                          type="button"
                          onClick={() =>
                            setDraft((current) => ({
                              ...current,
                              selectedCarritoIds: checked
                                ? current.selectedCarritoIds.filter((id) => id !== carrito.id)
                                : [...current.selectedCarritoIds, carrito.id]
                            }))
                          }
                          className={[
                            "grid gap-3 rounded-2xl border p-3 text-left transition md:grid-cols-[32px_1.2fr_1fr_150px]",
                            checked
                              ? "border-nostur-orange/50 bg-nostur-orange/10"
                              : "border-black/10 bg-[#f8fafc] hover:bg-white"
                          ].join(" ")}
                        >
                          <div
                            className={[
                              "flex h-7 w-7 items-center justify-center rounded-lg border text-[11px] font-black",
                              checked
                                ? "border-nostur-orange bg-nostur-orange text-white"
                                : "border-black/10 bg-white text-[#94a3b8]"
                            ].join(" ")}
                          >
                            {checked ? "✓" : ""}
                          </div>

                          <div className="min-w-0">
                            <div className="truncate text-xs font-black text-[#111827]">
                              {carrito.clientes?.nombre_completo || "Sin cliente"}
                            </div>
                            <div className="truncate text-[11px] font-bold text-nostur-orange">
                              {carrito.numero_carrito}
                            </div>
                            <div className="truncate text-[10px] font-bold text-[#64748b]">
                              {carrito.vendedor || "Sin vendedor"}
                            </div>
                          </div>

                          <div className="min-w-0">
                            <div className="truncate text-xs font-black text-[#111827]">
                              {carrito.destino || "Sin destino"}
                            </div>
                            <div className="truncate text-[11px] text-[#64748b]">
                              {carrito.servicio || "Sin servicio"} · {formatDateAR(carrito.fecha_venta)}
                            </div>
                          </div>

                          <div className="text-right">
                            <div className="text-xs font-black text-[#111827]">
                              {formatMoneyAR(control?.importe_a_facturar, carrito.moneda)}
                            </div>
                            <div className="text-[11px] text-[#64748b]">A facturar</div>
                          </div>
                        </button>
                      );
                    })
                  )}
                </div>
              </div>
            ) : (
              <div className="mt-4 rounded-2xl border border-black/10 bg-[#f8fafc] p-4 text-xs">
                <div className="flex justify-between">
                  <span className="text-[#64748b]">Importe sin IVA</span>
                  <strong>{formatMoneyAR(inputNeto, draft.moneda)}</strong>
                </div>

                <div className="flex justify-between">
                  <span className="text-[#64748b]">IVA 21%</span>
                  <strong>{formatMoneyAR(inputIva, draft.moneda)}</strong>
                </div>

                <div className="mt-2 flex justify-between border-t border-black/10 pt-2">
                  <span className="font-black text-[#111827]">Total</span>
                  <strong className="text-nostur-orange">{formatMoneyAR(inputTotal, draft.moneda)}</strong>
                </div>
              </div>
            )}
          </main>

          <aside className="rounded-[24px] border border-black/10 bg-[#f8fafc] p-4">
            <h3 className="mb-3 text-sm font-black text-[#111827]">Resumen documento</h3>

            <div className="grid gap-3 text-xs">
              <div>
                <FieldLabel>Tipo</FieldLabel>
                <div className="font-black text-[#111827]">{getTipoLabel(draft.tipo_documento)}</div>
              </div>

              <div>
                <FieldLabel>Número</FieldLabel>
                <div className="font-black text-[#111827]">{draft.numero_documento || "—"}</div>
              </div>

              <div>
                <FieldLabel>Sucursal / moneda</FieldLabel>
                <div className="font-black text-[#111827]">
                  {catalogos.sucursales.find((item) => item.id === draft.sucursal_id)?.nombre || "Sin sucursal"}
                </div>
                <div className="text-[#64748b]">{draft.moneda}</div>
              </div>

              <div className="rounded-2xl border border-black/10 bg-white p-3">
                <div className="flex justify-between gap-3">
                  <span className="text-[#64748b]">Carritos</span>
                  <strong>{selectedCarritos.length}</strong>
                </div>

                <div className="flex justify-between gap-3">
                  <span className="text-[#64748b]">Total</span>
                  <strong>{formatMoneyAR(isFacturaCarritos ? facturaCarritosTotal : inputTotal, draft.moneda)}</strong>
                </div>
              </div>
            </div>
          </aside>
        </div>

        <div className="mt-5 flex justify-between gap-2">
          <button
            type="button"
            onClick={onClose}
            className="h-9 rounded-xl px-4 text-xs font-bold text-[#64748b] hover:bg-black/5 hover:text-[#111827]"
          >
            Cancelar
          </button>

          <button
            type="button"
            disabled={saving}
            onClick={submit}
            className="h-9 rounded-xl bg-nostur-orange px-5 text-xs font-black text-white shadow-sm hover:bg-nostur-orangeSoft disabled:opacity-50"
          >
            {saving ? "Guardando..." : "Guardar documento"}
          </button>
        </div>
      </div>
    </div>
  );
}

function CobroMultipleModal({
  onClose,
  onSaved
}: {
  onClose: () => void;
  onSaved: () => void;
}) {
  const saving = useFacturasCobrarStore((state) => state.saving);
  const catalogos = useFacturasCobrarStore((state) => state.catalogos);

  const getSelectedFacturas = useFacturasCobrarStore((state) => state.getSelectedFacturas);
  const getSelectedTotal = useFacturasCobrarStore((state) => state.getSelectedTotal);
  const getSelectedMoneda = useFacturasCobrarStore((state) => state.getSelectedMoneda);
  const cobrarFacturasSeleccionadas = useFacturasCobrarStore((state) => state.cobrarFacturasSeleccionadas);

  const selectedFacturas = useMemo(() => getSelectedFacturas(), [getSelectedFacturas]);
  const selectedTotal = useMemo(() => getSelectedTotal(), [getSelectedTotal]);
  const selectedMoneda = useMemo(() => getSelectedMoneda(), [getSelectedMoneda]);

  const [draft, setDraft] = useState<CobroDraft>(() => createInitialCobroDraft(selectedTotal));

  const importeIngresado = draft.forma_cobro === "CASHFLOW" ? selectedTotal : parseMoney(draft.importe_ingresado_banco);
  const retencion = Math.max(selectedTotal - importeIngresado, 0);

  const cajaOptions: SelectOption[] = catalogos.cajas.map((item) => ({
    value: item.id,
    label: item.nombre
  }));

  function setField<K extends keyof CobroDraft>(key: K, value: CobroDraft[K]) {
    setDraft((current) => ({ ...current, [key]: value }));
  }

  async function submit() {
    const ok = await cobrarFacturasSeleccionadas(draft);
    if (ok) onSaved();
  }

  return (
    <div className="fixed inset-0 z-[230] flex items-start justify-center bg-black/25 px-4 pt-12 backdrop-blur-sm">
      <div className="max-h-[calc(100vh-72px)] w-full max-w-2xl overflow-auto rounded-[24px] border border-black/10 bg-white p-5 text-[#1f2937] shadow-2xl">
        <div className="mb-4 flex items-start justify-between gap-3">
          <div>
            <h2 className="text-lg font-black text-[#111827]">Registrar cobro agrupado</h2>
            <p className="text-xs text-[#64748b]">
              {selectedFacturas.length} factura/s · {formatMoneyAR(selectedTotal, selectedMoneda || "ARS")}
            </p>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="flex h-9 w-9 items-center justify-center rounded-xl text-[#64748b] hover:bg-black/5 hover:text-[#111827]"
          >
            <X size={17} />
          </button>
        </div>

        <div className="mb-4 rounded-2xl border border-black/10 bg-[#f8fafc] p-3">
          <FieldLabel>Facturas seleccionadas</FieldLabel>

          <div className="grid max-h-44 gap-2 overflow-auto pr-1">
            {selectedFacturas.map((factura) => (
              <div
                key={factura.id}
                className="flex items-center justify-between gap-3 rounded-xl border border-black/10 bg-white p-2 text-xs"
              >
                <div>
                  <div className="font-black text-[#111827]">{factura.numero_documento}</div>
                  <div className="text-[#64748b]">{factura.sucursal || "Sin sucursal"} · {factura.moneda}</div>
                </div>
                <div className="font-black text-nostur-orange">{formatMoneyAR(factura.total, factura.moneda)}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="grid gap-3">
          <div>
            <FieldLabel>Forma de cobro</FieldLabel>
            <NosturSelect
              value={draft.forma_cobro}
              onChange={(value) =>
                setDraft((current) => ({
                  ...current,
                  forma_cobro: value as CobroDraft["forma_cobro"],
                  importe_ingresado_banco:
                    value === "CASHFLOW" ? String(selectedTotal.toFixed(2)).replace(".", ",") : current.importe_ingresado_banco
                }))
              }
              options={FORMA_COBRO_OPTIONS}
            />
          </div>

          {draft.forma_cobro === "TRANSFERENCIA" ? (
            <>
              <div>
                <FieldLabel>Caja / banco destino</FieldLabel>
                <NosturSelect
                  value={draft.caja_id}
                  onChange={(value) => setField("caja_id", value)}
                  options={cajaOptions}
                  placeholder="Seleccionar caja/banco"
                />
              </div>

              <div>
                <FieldLabel>Importe ingresado realmente al banco</FieldLabel>
                <TextInput
                  value={draft.importe_ingresado_banco}
                  onChange={(value) => setField("importe_ingresado_banco", value)}
                  placeholder="0,00"
                  inputMode="decimal"
                />
              </div>
            </>
          ) : (
            <div className="rounded-2xl border border-amber-200 bg-amber-50 p-3 text-xs font-bold text-amber-700">
              Cashflow no impacta caja. Marca las facturas como cobradas por el total.
            </div>
          )}

          <div className="grid gap-3 md:grid-cols-3">
            <div className="rounded-2xl border border-black/10 bg-[#f8fafc] p-3">
              <div className="text-[10px] font-black uppercase tracking-wide text-[#64748b]">Total facturas</div>
              <div className="text-sm font-black text-[#111827]">
                {formatMoneyAR(selectedTotal, selectedMoneda || "ARS")}
              </div>
            </div>

            <div className="rounded-2xl border border-green-200 bg-green-50 p-3">
              <div className="text-[10px] font-black uppercase tracking-wide text-green-700">Ingreso banco</div>
              <div className="text-sm font-black text-green-800">
                {formatMoneyAR(importeIngresado, selectedMoneda || "ARS")}
              </div>
            </div>

            <div className="rounded-2xl border border-red-200 bg-red-50 p-3">
              <div className="text-[10px] font-black uppercase tracking-wide text-red-700">Retención</div>
              <div className="text-sm font-black text-red-800">
                {formatMoneyAR(retencion, selectedMoneda || "ARS")}
              </div>
            </div>
          </div>

          <div>
            <FieldLabel>Referencia</FieldLabel>
            <TextInput
              value={draft.referencia_cobro}
              onChange={(value) => setField("referencia_cobro", value)}
              placeholder="Transferencia, liquidación, referencia bancaria..."
            />
          </div>

          <div>
            <FieldLabel>Observaciones</FieldLabel>
            <TextArea
              value={draft.observaciones}
              onChange={(value) => setField("observaciones", value)}
              placeholder="Notas del cobro..."
            />
          </div>
        </div>

        <div className="mt-5 flex justify-between gap-2">
          <button
            type="button"
            onClick={onClose}
            className="h-9 rounded-xl px-4 text-xs font-bold text-[#64748b] hover:bg-black/5 hover:text-[#111827]"
          >
            Cancelar
          </button>

          <button
            type="button"
            disabled={saving}
            onClick={submit}
            className="h-9 rounded-xl bg-nostur-orange px-5 text-xs font-black text-white shadow-sm hover:bg-nostur-orangeSoft disabled:opacity-50"
          >
            {saving ? "Guardando..." : "Registrar cobro"}
          </button>
        </div>
      </div>
    </div>
  );
}

function FacturaDetailPanel({
  factura,
  onCobrar
}: {
  factura: FacturaCobrar | null;
  onCobrar: (factura: FacturaCobrar) => void;
}) {
  if (!factura) {
    return (
      <aside className="min-w-0 rounded-[24px] border border-black/10 bg-white/80 p-4 shadow-sm backdrop-blur">
        <div className="rounded-2xl border border-black/10 bg-[#f8fafc] p-5 text-center text-xs text-[#64748b]">
          Seleccioná una factura para ver el detalle.
        </div>
      </aside>
    );
  }

  return (
    <aside className="min-w-0 rounded-[24px] border border-black/10 bg-white/80 p-4 shadow-sm backdrop-blur">
      <div className="mb-4 flex items-start justify-between gap-3">
        <div className="flex min-w-0 items-center gap-3">
          <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-nostur-orange text-sm font-black text-white">
            {getInitials(factura.razon_social || "A")}
          </div>

          <div className="min-w-0">
            <h2 className="truncate text-sm font-black text-[#111827]">{factura.numero_documento}</h2>
            <p className="truncate text-xs text-[#64748b]">
              {getTipoLabel(factura.tipo_documento)} · {factura.sucursal || "Sin sucursal"}
            </p>
          </div>
        </div>

        {factura.cobrado || factura.estado === "COBRADA" ? (
          <StatusBadge type="ok">COBRADA</StatusBadge>
        ) : (
          <StatusBadge type="pending">PENDIENTE</StatusBadge>
        )}
      </div>

      <div className="grid gap-4 text-xs">
        <div className="rounded-2xl border border-black/10 bg-[#f8fafc] p-3">
          <FieldLabel>Documento</FieldLabel>
          <div className="font-black text-[#111827]">{getTipoLabel(factura.tipo_documento)}</div>
          <div className="text-[#64748b]">A: {factura.razon_social}</div>
          <div className="text-[#64748b]">Período: {getMonthName(factura.mes)} {factura.anio || ""}</div>
        </div>

        <div className="rounded-2xl border border-black/10 bg-[#f8fafc] p-3">
          <FieldLabel>Importes</FieldLabel>

          <div className="flex justify-between">
            <span>Neto</span>
            <strong>{formatMoneyAR(factura.neto_gravado, factura.moneda)}</strong>
          </div>

          <div className="flex justify-between">
            <span>IVA</span>
            <strong>{formatMoneyAR(factura.iva_importe, factura.moneda)}</strong>
          </div>

          <div className="mt-2 flex justify-between border-t border-black/10 pt-2">
            <span className="font-black text-[#111827]">Total</span>
            <strong className="text-nostur-orange">{formatMoneyAR(factura.total, factura.moneda)}</strong>
          </div>
        </div>

        {factura.facturas_cobrar_carritos && factura.facturas_cobrar_carritos.length > 0 ? (
          <div className="rounded-2xl border border-black/10 bg-[#f8fafc] p-3">
            <FieldLabel>Carritos incluidos</FieldLabel>

            <div className="grid max-h-[260px] gap-2 overflow-auto pr-1">
              {factura.facturas_cobrar_carritos.map((item) => (
                <div key={item.id} className="rounded-xl border border-black/10 bg-white p-2">
                  <div className="font-black text-[#111827]">{item.numero_carrito}</div>
                  <div className="text-[#64748b]">{item.pasajero || "Sin pasajero"}</div>
                  <div className="font-bold text-nostur-orange">
                    {formatMoneyAR(item.importe_facturado, item.moneda)}
                  </div>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div className="rounded-2xl border border-amber-200 bg-amber-50 p-3 text-amber-700">
            <FieldLabel>Vínculo a carritos</FieldLabel>
            <div className="font-bold">Esta factura no tiene carritos vinculados en la importación histórica.</div>
          </div>
        )}

        {factura.cobrado || factura.estado === "COBRADA" ? (
          <div className="rounded-2xl border border-green-200 bg-green-50 p-3 text-green-700">
            <FieldLabel>Detalle cobro</FieldLabel>
            <div className="font-black">{factura.forma_cobro || "Cobrado"}</div>
            <div>{factura.no_impacta_caja ? "Cashflow · no impacta caja" : factura.caja || "Sin caja"}</div>
            <div>{factura.referencia_cobro || "Sin referencia"}</div>
            <div className="mt-1 text-[11px] font-bold">Fecha cobro: {formatDateAR(factura.cobrado_at)}</div>
          </div>
        ) : (
          <button
            type="button"
            onClick={() => onCobrar(factura)}
            className="h-10 rounded-xl bg-nostur-orange px-4 text-xs font-black text-white shadow-sm hover:bg-nostur-orangeSoft"
          >
            Registrar cobro individual
          </button>
        )}

        {factura.observaciones ? (
          <div className="rounded-2xl border border-black/10 bg-[#f8fafc] p-3">
            <FieldLabel>Observaciones</FieldLabel>
            <div className="whitespace-pre-wrap text-[#334155]">{factura.observaciones}</div>
          </div>
        ) : null}
      </div>
    </aside>
  );
}

function GrupoMonedaCard({
  grupo,
  sucursal,
  onCobrarSeleccionadas
}: {
  grupo: FacturasGrupoMoneda;
  sucursal: FacturasGrupoSucursal;
  onCobrarSeleccionadas: () => void;
}) {
  const selectedFacturaIds = useFacturasCobrarStore((state) => state.selectedFacturaIds);
  const toggleFacturaSelection = useFacturasCobrarStore((state) => state.toggleFacturaSelection);
  const selectFactura = useFacturasCobrarStore((state) => state.selectFactura);

  const tieneSeleccion = grupo.cantidadSeleccionada > 0;

  return (
    <div className="rounded-[22px] border border-black/10 bg-white p-3 shadow-sm">
      <div className="mb-2 flex items-center justify-between gap-3">
        <div>
          <div className="text-sm font-black text-[#111827]">{grupo.moneda}</div>
          <div className="text-[11px] font-semibold text-[#64748b]">
            {grupo.facturas.length} factura/s · Total {formatMoneyAR(grupo.total, grupo.moneda)}
          </div>
        </div>

        <div className="text-right">
          <div className="text-[10px] font-black uppercase tracking-wide text-[#64748b]">Seleccionado</div>
          <div className="text-sm font-black text-nostur-orange">
            {formatMoneyAR(grupo.totalSeleccionado, grupo.moneda)}
          </div>
        </div>
      </div>

      <div className="grid gap-1.5">
        {grupo.facturas.map((factura) => {
          const checked = selectedFacturaIds.includes(factura.id);
          const cobrada = factura.cobrado || factura.estado === "COBRADA";

          return (
            <div
              key={factura.id}
              className={[
                "grid min-w-0 items-center gap-2 rounded-2xl border p-2 text-xs transition md:grid-cols-[34px_1.1fr_1fr_130px_96px_34px]",
                checked ? "border-nostur-orange/50 bg-nostur-orange/10" : "border-black/10 bg-[#f8fafc]"
              ].join(" ")}
            >
              <button
                type="button"
                disabled={cobrada}
                onClick={() => toggleFacturaSelection(factura.id)}
                className={[
                  "flex h-7 w-7 items-center justify-center rounded-lg border text-[11px] font-black",
                  checked
                    ? "border-nostur-orange bg-nostur-orange text-white"
                    : cobrada
                      ? "border-black/10 bg-white text-[#cbd5e1]"
                      : "border-black/10 bg-white text-[#94a3b8] hover:border-nostur-orange"
                ].join(" ")}
                title={cobrada ? "Factura ya cobrada" : "Seleccionar factura"}
              >
                {checked ? "✓" : ""}
              </button>

              <div className="min-w-0">
                <div className="truncate font-black text-[#111827]">{factura.numero_documento}</div>
                <div className="truncate text-[10px] font-bold text-nostur-orange">{getTipoLabel(factura.tipo_documento)}</div>
              </div>

              <div className="min-w-0">
                <div className="truncate font-bold text-[#334155]">{factura.razon_social}</div>
                <div className="truncate text-[10px] text-[#64748b]">{sucursal.sucursal}</div>
              </div>

              <div className="text-right font-black text-[#111827]">
                {formatMoneyAR(factura.total, factura.moneda)}
              </div>

              <div className="flex justify-end">
                {cobrada ? <StatusBadge type="ok">COBRADA</StatusBadge> : <StatusBadge type="pending">PENDIENTE</StatusBadge>}
              </div>

              <IconButton
                icon={Eye}
                label="Ver detalle"
                onClick={() => selectFactura(factura.id)}
              />
            </div>
          );
        })}
      </div>

      {tieneSeleccion ? (
        <div className="mt-3 flex items-center justify-between gap-3 rounded-2xl border border-nostur-orange/20 bg-nostur-orange/10 p-3">
          <div>
            <div className="text-xs font-black text-[#111827]">
              {grupo.cantidadSeleccionada} seleccionada/s
            </div>
            <div className="text-[11px] font-bold text-[#64748b]">
              Total seleccionado: {formatMoneyAR(grupo.totalSeleccionado, grupo.moneda)}
            </div>
          </div>

          <button
            type="button"
            onClick={onCobrarSeleccionadas}
            className="h-8 rounded-xl bg-nostur-orange px-3 text-[11px] font-black text-white shadow-sm hover:bg-nostur-orangeSoft"
          >
            Registrar cobro
          </button>
        </div>
      ) : null}
    </div>
  );
}

export function FacturasCobrarPanel() {
  const loading = useFacturasCobrarStore((state) => state.loading);
  const saving = useFacturasCobrarStore((state) => state.saving);
  const error = useFacturasCobrarStore((state) => state.error);
  const filters = useFacturasCobrarStore((state) => state.filters);
  const selectedTab = useFacturasCobrarStore((state) => state.selectedTab);
  const selectedFacturaId = useFacturasCobrarStore((state) => state.selectedFacturaId);
  const selectedFacturaIds = useFacturasCobrarStore((state) => state.selectedFacturaIds);
  const catalogos = useFacturasCobrarStore((state) => state.catalogos);
  const retenciones = useFacturasCobrarStore((state) => state.retenciones);

  const loadFacturas = useFacturasCobrarStore((state) => state.loadFacturas);
  const setTab = useFacturasCobrarStore((state) => state.setTab);
  const setFilter = useFacturasCobrarStore((state) => state.setFilter);
  const clearError = useFacturasCobrarStore((state) => state.clearError);
  const clearSelection = useFacturasCobrarStore((state) => state.clearSelection);
  const selectFactura = useFacturasCobrarStore((state) => state.selectFactura);
  const selectOnlyFactura = useFacturasCobrarStore((state) => state.selectOnlyFactura);
  const goToPreviousMonth = useFacturasCobrarStore((state) => state.goToPreviousMonth);
  const goToNextMonth = useFacturasCobrarStore((state) => state.goToNextMonth);
  const goToCurrentMonth = useFacturasCobrarStore((state) => state.goToCurrentMonth);

  const getFilteredFacturas = useFacturasCobrarStore((state) => state.getFilteredFacturas);
  const getFacturasAgrupadas = useFacturasCobrarStore((state) => state.getFacturasAgrupadas);

  const facturas = getFilteredFacturas();
  const grupos = getFacturasAgrupadas();

  const selectedFactura = useMemo(() => {
    if (!selectedFacturaId) return facturas[0] || null;
    return facturas.find((factura) => factura.id === selectedFacturaId) || facturas[0] || null;
  }, [facturas, selectedFacturaId]);

  const [filtersOpen, setFiltersOpen] = useState(false);
  const [documentModalOpen, setDocumentModalOpen] = useState(false);
  const [cobroModalOpen, setCobroModalOpen] = useState(false);
  const [toast, setToast] = useState<ToastState>(null);

  const mesActual = filters.mes;
  const anioActual = filters.anio;

  function showToast(message: string, type: "success" | "error" = "success") {
    setToast({ type, message });
    window.setTimeout(() => setToast(null), 3200);
  }

  function reloadAfterFilterChange(callback: () => void) {
    callback();
    selectFactura(null);
    clearSelection();

    window.setTimeout(() => {
      loadFacturas();
    }, 0);
  }

  function handleTab(tab: FacturasTab) {
    reloadAfterFilterChange(() => setTab(tab));
  }

  function openCobroForFactura(factura: FacturaCobrar) {
    selectOnlyFactura(factura.id);
    setCobroModalOpen(true);
  }

  useEffect(() => {
    loadFacturas();
  }, [loadFacturas]);

  const sucursalOptions: SelectOption[] = [
    { value: "todos", label: "Todas" },
    ...catalogos.sucursales.map((item) => ({
      value: item.id,
      label: item.nombre
    }))
  ];

  const selectedCount = selectedFacturaIds.length;

  return (
    <div className="h-full overflow-auto bg-[radial-gradient(circle_at_22%_10%,rgba(255,122,26,0.10),transparent_28%),radial-gradient(circle_at_78%_18%,rgba(90,120,190,0.13),transparent_30%),linear-gradient(135deg,#eef1f6,#e1e7f0_48%,#eef1f6)] px-6 py-5 text-[#1f2937]">
      <div className="mx-auto w-full max-w-[calc(100vw-110px)]">
        <div className="mb-2 flex flex-wrap items-center gap-2">
          <h1 className="text-xl font-black tracking-tight text-[#111827]">Facturas a cobrar</h1>

          <span className="rounded-xl bg-white/80 px-2 py-1 text-[10px] font-black uppercase tracking-wide text-[#64748b]">
            ALMUNDO
          </span>

          <span className="text-xs font-semibold text-[#64748b]">
            Sucursales, monedas, cobros agrupados y retenciones
          </span>
        </div>

        {error ? (
          <div className="mb-4 flex items-start justify-between gap-3 rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-xs font-semibold text-red-700">
            <span>{error}</span>
            <button onClick={clearError} className="text-red-500 hover:text-red-700">
              <X size={14} />
            </button>
          </div>
        ) : null}

        <section className="relative z-[30] mb-3 rounded-[22px] border border-black/10 bg-white/55 px-3 py-2 shadow-sm backdrop-blur">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex flex-wrap items-center gap-2">
              <div className="flex h-9 overflow-hidden rounded-[16px] border border-black/10 bg-white/80 p-0.5 shadow-sm">
                <button
                  type="button"
                  onClick={() => reloadAfterFilterChange(() => goToPreviousMonth())}
                  className="h-8 rounded-[13px] px-3 text-[11px] font-black text-[#334155] transition hover:bg-white"
                >
                  Mes anterior
                </button>

                <div className="flex h-8 min-w-[132px] items-center justify-center rounded-[13px] bg-[#111827] px-4 text-xs font-black text-white">
                  {getMonthYearLabel(mesActual, anioActual)}
                </div>

                <button
                  type="button"
                  onClick={() => reloadAfterFilterChange(() => goToNextMonth())}
                  className="h-8 rounded-[13px] px-3 text-[11px] font-black text-[#334155] transition hover:bg-white"
                >
                  Mes siguiente
                </button>
              </div>

              <button
                type="button"
                onClick={() => reloadAfterFilterChange(() => goToCurrentMonth())}
                className="h-8 rounded-[13px] bg-nostur-orange px-3 text-[11px] font-black text-white shadow-sm hover:bg-nostur-orangeSoft"
              >
                Este mes
              </button>
            </div>

            <div className="flex shrink-0 flex-wrap items-center gap-2">
              <div className="flex h-9 overflow-hidden rounded-[16px] border border-black/10 bg-white/80 p-0.5 shadow-sm">
                <button
                  type="button"
                  onClick={() => handleTab("PENDIENTE")}
                  className={[
                    "flex h-8 items-center gap-1.5 rounded-[13px] px-3 text-[11px] font-black transition",
                    selectedTab === "PENDIENTE"
                      ? "bg-nostur-orange text-white"
                      : "text-[#64748b] hover:bg-white hover:text-[#111827]"
                  ].join(" ")}
                >
                  <ReceiptText size={12} strokeWidth={1.8} />
                  Pendientes
                </button>

                <button
                  type="button"
                  onClick={() => handleTab("COBRADA")}
                  className={[
                    "flex h-8 items-center gap-1.5 rounded-[13px] px-3 text-[11px] font-black transition",
                    selectedTab === "COBRADA"
                      ? "bg-green-600 text-white"
                      : "text-[#64748b] hover:bg-white hover:text-[#111827]"
                  ].join(" ")}
                >
                  <Archive size={12} strokeWidth={1.8} />
                  Cobradas
                </button>

                <button
                  type="button"
                  onClick={() => handleTab("RETENCIONES")}
                  className={[
                    "flex h-8 items-center gap-1.5 rounded-[13px] px-3 text-[11px] font-black transition",
                    selectedTab === "RETENCIONES"
                      ? "bg-red-600 text-white"
                      : "text-[#64748b] hover:bg-white hover:text-[#111827]"
                  ].join(" ")}
                >
                  <ShieldCheck size={12} strokeWidth={1.8} />
                  Retenciones
                </button>
              </div>

              <button
                type="button"
                onClick={loadFacturas}
                disabled={loading}
                className="flex h-8 items-center gap-2 rounded-[13px] bg-white/80 px-3 text-[11px] font-black text-[#334155] shadow-sm hover:bg-white disabled:opacity-50"
              >
                <RefreshCcw size={12} strokeWidth={1.8} />
                Actualizar
              </button>

              <button
                type="button"
                onClick={() => setDocumentModalOpen(true)}
                className="flex h-8 items-center gap-2 rounded-[13px] bg-nostur-orange px-3 text-[11px] font-black text-white shadow-sm hover:bg-nostur-orangeSoft"
              >
                <Plus size={12} strokeWidth={1.8} />
                Nuevo documento
              </button>

              <button
                type="button"
                onClick={() => setFiltersOpen((current) => !current)}
                className="flex h-8 items-center gap-2 rounded-[13px] bg-white/80 px-3 text-[11px] font-black text-[#334155] shadow-sm hover:bg-white"
              >
                {filtersOpen ? "Ocultar" : "Mostrar"}
                <ChevronsUpDown size={13} strokeWidth={1.8} />
              </button>
            </div>
          </div>

          {filtersOpen ? (
            <>
              <div className="mt-4 grid gap-3 lg:grid-cols-[1fr_1fr_1fr_1fr_1fr]">
                <div>
                  <FieldLabel>Moneda</FieldLabel>
                  <NosturSelect
                    value={filters.moneda}
                    onChange={(value) => setFilter("moneda", value as typeof filters.moneda)}
                    options={MONEDA_OPTIONS}
                  />
                </div>

                <div>
                  <FieldLabel>Sucursal</FieldLabel>
                  <NosturSelect
                    value={filters.sucursalId}
                    onChange={(value) => setFilter("sucursalId", value)}
                    options={sucursalOptions}
                  />
                </div>

                <div>
                  <FieldLabel>Estado</FieldLabel>
                  <NosturSelect
                    value={filters.estado}
                    onChange={(value) => setFilter("estado", value as typeof filters.estado)}
                    options={ESTADO_OPTIONS}
                  />
                </div>

                <div>
                  <FieldLabel>Tipo</FieldLabel>
                  <NosturSelect
                    value={filters.tipoDocumento}
                    onChange={(value) => setFilter("tipoDocumento", value as typeof filters.tipoDocumento)}
                    options={TIPO_DOCUMENTO_OPTIONS}
                  />
                </div>

                <div>
                  <FieldLabel>Período</FieldLabel>
                  <div className="flex h-9 items-center rounded-xl border border-black/10 bg-[#f8fafc] px-3 text-xs font-black text-[#334155]">
                    {getMonthYearLabel(mesActual, anioActual)}
                  </div>
                </div>
              </div>

              <div className="mt-3 grid gap-3 lg:grid-cols-[minmax(0,1fr)_auto_auto]">
                <div className="flex h-10 items-center gap-2 rounded-2xl border border-black/10 bg-white/80 px-3">
                  <Search size={15} className="shrink-0 text-[#64748b]" />

                  <input
                    value={filters.search}
                    onChange={(event) => setFilter("search", event.target.value)}
                    placeholder="Buscar por número, tipo, sucursal, observación..."
                    className="h-full min-w-0 flex-1 bg-transparent text-xs font-semibold outline-none placeholder:text-[#94a3b8]"
                  />
                </div>

                <button
                  type="button"
                  onClick={loadFacturas}
                  className="h-10 rounded-2xl bg-white/80 px-4 text-xs font-black text-[#334155] shadow-sm hover:bg-white"
                >
                  Aplicar filtros
                </button>

                <button
                  type="button"
                  className="h-10 rounded-2xl bg-white/80 px-4 text-xs font-black text-[#334155] shadow-sm hover:bg-white"
                  title="La exportación se agrega en la próxima etapa."
                >
                  Exportar Excel
                </button>
              </div>
            </>
          ) : null}
        </section>

        {selectedTab !== "RETENCIONES" && selectedCount > 0 ? (
          <section className="mb-3 flex flex-wrap items-center justify-between gap-3 rounded-[22px] border border-nostur-orange/20 bg-nostur-orange/10 p-3">
            <div>
              <div className="text-sm font-black text-[#111827]">
                {selectedCount} factura/s seleccionada/s
              </div>
              <div className="text-xs font-bold text-[#64748b]">
                Se pueden agrupar solamente facturas de la misma sucursal y moneda.
              </div>
            </div>

            <div className="flex gap-2">
              <button
                type="button"
                onClick={clearSelection}
                className="h-9 rounded-xl bg-white/80 px-4 text-xs font-black text-[#334155] shadow-sm hover:bg-white"
              >
                Limpiar selección
              </button>

              <button
                type="button"
                onClick={() => setCobroModalOpen(true)}
                className="h-9 rounded-xl bg-nostur-orange px-4 text-xs font-black text-white shadow-sm hover:bg-nostur-orangeSoft"
              >
                Registrar cobro agrupado
              </button>
            </div>
          </section>
        ) : null}

        {selectedTab === "RETENCIONES" ? (
          <section className="rounded-[24px] border border-black/10 bg-white/70 p-4 shadow-sm backdrop-blur">
            <div className="mb-3 flex items-center justify-between gap-3">
              <div>
                <h2 className="text-sm font-black text-[#111827]">Retenciones registradas</h2>
                <p className="text-[11px] text-[#64748b]">
                  {loading ? "Cargando..." : `${retenciones.length} retenciones encontradas`}
                </p>
              </div>

              <div className="rounded-xl bg-white/80 px-3 py-1.5 text-[10px] font-black uppercase tracking-wide text-[#64748b]">
                {getMonthYearLabel(filters.mes, filters.anio)}
              </div>
            </div>

            {retenciones.length === 0 ? (
              <div className="rounded-2xl border border-black/10 bg-[#f8fafc] p-5 text-center text-xs text-[#64748b]">
                No hay retenciones registradas para este período.
              </div>
            ) : (
              <div className="grid gap-2">
                {retenciones.map((retencion) => (
                  <div
                    key={retencion.id}
                    className="grid gap-3 rounded-2xl border border-black/10 bg-[#f8fafc] p-3 text-xs md:grid-cols-[110px_1fr_1fr_120px_120px_120px]"
                  >
                    <div>
                      <div className="font-black text-[#111827]">{formatDateAR(retencion.fecha_cobro)}</div>
                      <div className="text-[10px] font-bold text-[#64748b]">Fecha</div>
                    </div>

                    <div>
                      <div className="font-black text-[#111827]">{retencion.numero_documento}</div>
                      <div className="text-[10px] font-bold text-[#64748b]">Factura</div>
                    </div>

                    <div>
                      <div className="font-black text-[#111827]">{retencion.sucursal || "Sin sucursal"}</div>
                      <div className="text-[10px] font-bold text-[#64748b]">{retencion.moneda}</div>
                    </div>

                    <div className="text-right">
                      <div className="font-black text-[#111827]">
                        {formatMoneyAR(retencion.importe_factura, retencion.moneda)}
                      </div>
                      <div className="text-[10px] font-bold text-[#64748b]">Factura</div>
                    </div>

                    <div className="text-right">
                      <div className="font-black text-green-700">
                        {formatMoneyAR(retencion.importe_cobrado, retencion.moneda)}
                      </div>
                      <div className="text-[10px] font-bold text-[#64748b]">Cobrado</div>
                    </div>

                    <div className="text-right">
                      <div className="font-black text-red-700">
                        {formatMoneyAR(retencion.importe_retencion, retencion.moneda)}
                      </div>
                      <div className="text-[10px] font-bold text-[#64748b]">Retención</div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </section>
        ) : (
          <div className="grid gap-4 xl:grid-cols-[minmax(0,1fr)_400px]">
            <section className="min-w-0 rounded-[24px] border border-black/10 bg-white/70 p-4 shadow-sm backdrop-blur">
              <div className="mb-3 flex items-center justify-between gap-3">
                <div>
                  <h2 className="text-sm font-black text-[#111827]">
                    {selectedTab === "COBRADA" ? "Facturas cobradas" : "Documentos a cobrar"}
                  </h2>

                  <p className="text-[11px] text-[#64748b]">
                    {loading ? "Cargando..." : `${facturas.length} documentos encontrados`}
                  </p>
                </div>

                <div className="rounded-xl bg-white/80 px-3 py-1.5 text-[10px] font-black uppercase tracking-wide text-[#64748b]">
                  {getMonthYearLabel(filters.mes, filters.anio)}
                </div>
              </div>

              {loading ? (
                <div className="rounded-2xl border border-black/10 bg-[#f8fafc] p-5 text-center text-xs text-[#64748b]">
                  Cargando facturas...
                </div>
              ) : grupos.length === 0 ? (
                <div className="rounded-2xl border border-black/10 bg-[#f8fafc] p-5 text-center text-xs text-[#64748b]">
                  No hay documentos para los filtros seleccionados.
                </div>
              ) : (
                <div className="grid gap-4">
                  {grupos.map((grupo) => (
                    <div
                      key={grupo.sucursalId || "sin-sucursal"}
                      className="rounded-[24px] border border-black/10 bg-white/70 p-3"
                    >
                      <div className="mb-3 flex items-center justify-between gap-3">
                        <div className="flex items-center gap-2">
                          <Wallet size={17} className="text-nostur-orange" />
                          <h3 className="text-sm font-black text-[#111827]">{grupo.sucursal}</h3>
                        </div>

                        <span className="rounded-xl bg-[#f8fafc] px-2 py-1 text-[10px] font-black uppercase tracking-wide text-[#64748b]">
                          {grupo.monedas.reduce((total, item) => total + item.facturas.length, 0)} factura/s
                        </span>
                      </div>

                      <div className="grid gap-3">
                        {grupo.monedas.map((monedaGrupo) => (
                          <GrupoMonedaCard
                            key={`${grupo.sucursalId || "sin-sucursal"}-${monedaGrupo.moneda}`}
                            grupo={monedaGrupo}
                            sucursal={grupo}
                            onCobrarSeleccionadas={() => setCobroModalOpen(true)}
                          />
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </section>

            <FacturaDetailPanel factura={selectedFactura} onCobrar={openCobroForFactura} />
          </div>
        )}
      </div>

      <Toast toast={toast} onClose={() => setToast(null)} />

      {documentModalOpen ? (
        <DocumentoModal
          onClose={() => setDocumentModalOpen(false)}
          onSaved={() => {
            setDocumentModalOpen(false);
            showToast("Documento creado correctamente.");
          }}
        />
      ) : null}

      {cobroModalOpen ? (
        <CobroMultipleModal
          onClose={() => setCobroModalOpen(false)}
          onSaved={() => {
            setCobroModalOpen(false);
            showToast("Cobro registrado correctamente.");
          }}
        />
      ) : null}

      {saving ? null : null}
    </div>
  );
}