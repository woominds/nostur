import { useEffect, useMemo, useState } from "react";
import type { ReactNode } from "react";
import {
  Building2,
  CalendarClock,
  ChevronsUpDown,
  Edit3,
 
  Plus,
  RefreshCcw,
  Search,
  Target,
  Trophy,
  UsersRound,
  X
} from "lucide-react";
import {
  useMetasStore,
  type CreateMetaDraft,
  type MetaDraft,
  type MetaResumen,
  type MetaTipo
} from "../../store/metasStore";
import { IconButton } from "../ui/IconButton";
import { formatMoneyAR } from "../../lib/formatters";
import { NosturDateInput } from "../ui/NosturDateInput";

type SelectOption = {
  value: string;
  label: string;
};

type ToastState = {
  type: "success" | "error";
  message: string;
} | null;

const MONTH_NAMES = [
  "Enero",
  "Febrero",
  "Marzo",
  "Abril",
  "Mayo",
  "Junio",
  "Julio",
  "Agosto",
  "Septiembre",
  "Octubre",
  "Noviembre",
  "Diciembre"
];

const TIPO_OPTIONS: SelectOption[] = [
  { value: "todos", label: "Todas" },
  { value: "VENDEDOR_SEMANAL", label: "Vendedor semanal" },
  { value: "VENDEDOR_MENSUAL", label: "Vendedor mensual" },
  { value: "SUCURSAL_MENSUAL", label: "Utilidad sucursal" },
  { value: "ALMUNDO_MENSUAL", label: "Meta Almundo" }
];

const TIPO_CREATE_OPTIONS: SelectOption[] = [
  { value: "ALMUNDO_MENSUAL", label: "Meta Almundo por sucursal" },
  { value: "SUCURSAL_MENSUAL", label: "Meta utilidad por sucursal" },
  { value: "VENDEDOR_MENSUAL", label: "Meta mensual vendedores" },
  { value: "VENDEDOR_SEMANAL", label: "Meta semanal vendedores" }
];

const ESTADO_OPTIONS: SelectOption[] = [
  { value: "todos", label: "Todos" },
  { value: "ACTIVA", label: "Activas" },
  { value: "INACTIVA", label: "Inactivas" },
  { value: "VENCIDA", label: "Vencidas" },
  { value: "FUTURA", label: "Futuras" }
];



function monthStart(anio: string, mes: string): string {
  return `${anio}-${mes.padStart(2, "0")}-01`;
}

function monthEnd(anio: string, mes: string): string {
  const year = Number(anio);
  const month = Number(mes);
  const last = new Date(year, month, 0).getDate();

  return `${anio}-${mes.padStart(2, "0")}-${String(last).padStart(2, "0")}`;
}

function parseMoney(value: string | number | null | undefined): number {
  if (typeof value === "number") return Number.isFinite(value) ? value : 0;

  const normalized = String(value || "")
    .replace(/\./g, "")
    .replace(",", ".")
    .replace(/[^\d.-]/g, "");

  const parsed = Number(normalized);
  return Number.isFinite(parsed) ? parsed : 0;
}

function formatInputMoney(value: string | number | null | undefined): string {
  const parsed = parseMoney(value);
  if (!parsed) return "";

  return new Intl.NumberFormat("es-AR", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  }).format(parsed);
}

function formatDate(value?: string | null): string {
  if (!value) return "—";

  const [year, month, day] = value.slice(0, 10).split("-");
  if (!year || !month || !day) return "—";

  return `${day}/${month}/${year}`;
}

function getMonthYearLabel(mes: string, anio: string): string {
  const monthIndex = Number(mes) - 1;
  return `${MONTH_NAMES[monthIndex] || "Mes"} ${anio}`;
}

function getNombreCompleto(profile?: { nombre?: string; apellido?: string; email?: string } | null): string {
  if (!profile) return "Todos los vendedores";

  return `${profile.nombre || ""} ${profile.apellido || ""}`.trim() || profile.email || "Vendedor";
}

function getTipoLabel(tipo: string): string {
  const labels: Record<string, string> = {
    VENDEDOR_SEMANAL: "Vendedor semanal",
    VENDEDOR_MENSUAL: "Vendedor mensual",
    SUCURSAL_MENSUAL: "Utilidad sucursal",
    ALMUNDO_MENSUAL: "Meta Almundo"
  };

  return labels[tipo] || tipo;
}

function getBaseLabel(tipo: MetaTipo): string {
  if (tipo === "ALMUNDO_MENSUAL") return "Facturación de Carritos Almundo · sin Files";
  if (tipo === "VENDEDOR_SEMANAL") return "Utilidad USD · incentivo sin comisión";
  if (tipo === "VENDEDOR_MENSUAL") return "Utilidad USD · comisiones 8% / 10% / 12%";
  return "Utilidad USD de sucursal · Carritos + Files";
}

function getEstadoType(estado: string): "ok" | "pending" | "danger" | "neutral" {
  if (estado === "ACTIVA") return "ok";
  if (estado === "FUTURA") return "neutral";
  if (estado === "VENCIDA") return "pending";
  return "danger";
}

function FieldLabel({ children }: { children: ReactNode }) {
  return (
    <label className="mb-1.5 block text-[10px] font-black uppercase tracking-[0.14em] text-[#64748b]">
      {children}
    </label>
  );
}

function TextInput({
  value,
  onChange,
  placeholder,
  inputMode = "text"
}: {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  inputMode?: React.HTMLAttributes<HTMLInputElement>["inputMode"];
}) {
  return (
    <input
      value={value}
      onChange={(event) => onChange(event.target.value)}
      placeholder={placeholder}
      inputMode={inputMode}
      className="h-9 w-full rounded-xl border border-black/10 bg-[#f8fafc] px-3 text-xs font-semibold text-[#111827] outline-none transition focus:border-nostur-orange"
    />
  );
}

function TextArea({
  value,
  onChange,
  placeholder
}: {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
}) {
  return (
    <textarea
      value={value}
      onChange={(event) => onChange(event.target.value)}
      placeholder={placeholder}
      className="min-h-[82px] w-full resize-none rounded-xl border border-black/10 bg-white px-3 py-2 text-xs font-semibold text-[#111827] outline-none transition focus:border-nostur-orange"
    />
  );
}

function NosturSelect({
  value,
  onChange,
  options,
  placeholder = "Seleccionar"
}: {
  value: string;
  onChange: (value: string) => void;
  options: SelectOption[];
  placeholder?: string;
}) {
  const [open, setOpen] = useState(false);
  const selected = options.find((option) => option.value === value);

  return (
    <div className={["relative", open ? "z-[160]" : "z-0"].join(" ")}>
      <button
        type="button"
        onClick={() => setOpen((current) => !current)}
        className="flex h-9 w-full items-center justify-between gap-2 rounded-xl border border-black/10 bg-[#f8fafc] px-3 text-left text-xs font-semibold text-[#111827] outline-none transition hover:bg-white"
      >
        <span className={selected ? "truncate" : "truncate text-[#94a3b8]"}>
          {selected?.label || placeholder}
        </span>
        <ChevronsUpDown size={14} strokeWidth={1.8} className="shrink-0 text-[#64748b]" />
      </button>

      {open ? (
        <>
          <button
            type="button"
            className="fixed inset-0 z-[140] cursor-default bg-transparent"
            onClick={() => setOpen(false)}
            tabIndex={-1}
          />

          <div className="absolute left-0 right-0 top-[42px] z-[170] max-h-56 overflow-auto rounded-2xl border border-black/10 bg-white p-1 shadow-xl">
            {options.length === 0 ? (
              <div className="px-3 py-2 text-xs font-bold text-[#94a3b8]">Sin opciones</div>
            ) : (
              options.map((option) => {
                const active = option.value === value;

                return (
                  <button
                    key={option.value}
                    type="button"
                    onClick={() => {
                      onChange(option.value);
                      setOpen(false);
                    }}
                    className={[
                      "flex h-8 w-full items-center rounded-xl px-3 text-left text-xs font-bold transition",
                      active ? "bg-nostur-orange text-white" : "text-[#334155] hover:bg-[#f1f5f9]"
                    ].join(" ")}
                  >
                    <span className="truncate">{option.label}</span>
                  </button>
                );
              })
            )}
          </div>
        </>
      ) : null}
    </div>
  );
}

function StatusBadge({
  children,
  type
}: {
  children: ReactNode;
  type: "ok" | "pending" | "danger" | "neutral";
}) {
  const className = {
    ok: "border-green-200 bg-green-50 text-green-700",
    pending: "border-amber-200 bg-amber-50 text-amber-700",
    danger: "border-red-200 bg-red-50 text-red-700",
    neutral: "border-blue-200 bg-blue-50 text-blue-700"
  }[type];

  return (
    <span className={["rounded-xl border px-2.5 py-1 text-[10px] font-black uppercase tracking-wide", className].join(" ")}>
      {children}
    </span>
  );
}

function Toast({ toast, onClose }: { toast: ToastState; onClose: () => void }) {
  if (!toast) return null;

  return (
    <div className="fixed right-5 top-5 z-[260] w-[320px] rounded-2xl border border-black/10 bg-white p-4 text-xs shadow-2xl">
      <div className="flex items-start justify-between gap-3">
        <div>
          <div
            className={[
              "mb-1 font-black",
              toast.type === "success" ? "text-green-700" : "text-red-700"
            ].join(" ")}
          >
            {toast.type === "success" ? "Operación exitosa" : "Atención"}
          </div>
          <div className="font-semibold text-[#334155]">{toast.message}</div>
        </div>

        <button
          type="button"
          onClick={onClose}
          className="flex h-7 w-7 shrink-0 items-center justify-center rounded-xl text-[#64748b] hover:bg-[#f1f5f9] hover:text-[#111827]"
        >
          <X size={14} />
        </button>
      </div>
    </div>
  );
}

function MetricCard({
  label,
  value,
  icon: Icon
}: {
  label: string;
  value: string | number;
  icon: typeof Target;
}) {
  return (
    <div className="rounded-2xl border border-black/10 bg-white/70 p-3 shadow-sm">
      <div className="flex items-center gap-3">
        <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-nostur-orange/15 text-nostur-orange">
          <Icon size={17} strokeWidth={1.8} />
        </div>

        <div className="min-w-0">
          <div className="truncate text-lg font-black text-[#111827]">{value}</div>
          <div className="text-[11px] font-bold text-[#64748b]">{label}</div>
        </div>
      </div>
    </div>
  );
}

function buildInitialDraft(selected: MetaResumen | null): MetaDraft {
  const meta = selected?.meta;

  return {
    fecha_desde: meta?.fecha_desde || "",
    fecha_hasta: meta?.fecha_hasta || "",
    mes: meta?.mes ? String(meta.mes).padStart(2, "0") : "",
    anio: meta?.anio ? String(meta.anio) : "",
    meta_unica_usd: formatInputMoney(meta?.meta_unica_usd),
    meta_piso_usd: formatInputMoney(meta?.meta_piso_usd),
    meta_medio_usd: formatInputMoney(meta?.meta_medio_usd),
    meta_logrado_usd: formatInputMoney(meta?.meta_logrado_usd),
    comision_piso_pct: String(meta?.comision_piso_pct ?? "8").replace(".", ","),
    comision_medio_pct: String(meta?.comision_medio_pct ?? "10").replace(".", ","),
    comision_logrado_pct: String(meta?.comision_logrado_pct ?? "12").replace(".", ","),
    activa: meta?.activa ?? true,
    observaciones: meta?.observaciones || ""
  };
}

function buildInitialCreateDraft(mes: string, anio: string): CreateMetaDraft {
  return {
    tipo: "ALMUNDO_MENSUAL",
    alcance: "ESPECIFICO",
    sucursal_id: "",
    vendedor_id: "",
    fecha_desde: monthStart(anio, mes),
    fecha_hasta: monthEnd(anio, mes),
    mes,
    anio,
    meta_unica_usd: "",
    meta_piso_usd: "",
    meta_medio_usd: "",
    meta_logrado_usd: "",
    comision_piso_pct: "8",
    comision_medio_pct: "10",
    comision_logrado_pct: "12",
    observaciones: ""
  };
}

function MetaCreateModal({
  onClose,
  onSaved
}: {
  onClose: () => void;
  onSaved: () => void;
}) {
  const saving = useMetasStore((state) => state.saving);
  const filters = useMetasStore((state) => state.filters);
  const catalogos = useMetasStore((state) => state.catalogos);
  const createMeta = useMetasStore((state) => state.createMeta);

  const [draft, setDraft] = useState<CreateMetaDraft>(() => buildInitialCreateDraft(filters.mes, filters.anio));

  const isVendedor = draft.tipo === "VENDEDOR_MENSUAL" || draft.tipo === "VENDEDOR_SEMANAL";
  const isSucursal = draft.tipo === "SUCURSAL_MENSUAL" || draft.tipo === "ALMUNDO_MENSUAL";
  const isWeekly = draft.tipo === "VENDEDOR_SEMANAL";
  const isAlmundo = draft.tipo === "ALMUNDO_MENSUAL";
  const isMonthlySeller = draft.tipo === "VENDEDOR_MENSUAL";

  const sucursalOptions: SelectOption[] = catalogos.sucursales.map((item) => ({
    value: item.id,
    label: item.nombre
  }));

  const vendedorOptions: SelectOption[] = catalogos.vendedores.map((item) => ({
    value: item.id,
    label: getNombreCompleto(item)
  }));

  function setField<K extends keyof CreateMetaDraft>(key: K, value: CreateMetaDraft[K]) {
    setDraft((current) => ({ ...current, [key]: value }));
  }

  function setPeriodo(mes: string, anio: string) {
    setDraft((current) => ({
      ...current,
      mes,
      anio,
      fecha_desde: monthStart(anio, mes),
      fecha_hasta: monthEnd(anio, mes)
    }));
  }

  function handleTipoChange(value: string) {
    const tipo = value as MetaTipo;
    const nextIsVendedor = tipo === "VENDEDOR_MENSUAL" || tipo === "VENDEDOR_SEMANAL";

    setDraft((current) => ({
      ...current,
      tipo,
      alcance: nextIsVendedor ? "TODOS" : "ESPECIFICO",
      sucursal_id: "",
      vendedor_id: "",
      meta_unica_usd: "",
      meta_piso_usd: "",
      meta_medio_usd: "",
      meta_logrado_usd: "",
      observaciones: ""
    }));
  }

  async function submit() {
    const ok = await createMeta(draft);

    if (ok) onSaved();
  }

  return (
    <div className="fixed inset-0 z-[230] flex items-start justify-center bg-black/25 px-4 pt-8 backdrop-blur-sm">
      <div className="max-h-[calc(100vh-56px)] w-full max-w-4xl overflow-auto rounded-[24px] border border-black/10 bg-white p-5 text-[#1f2937] shadow-2xl">
        <div className="mb-4 flex items-start justify-between gap-3">
          <div>
            <h2 className="text-lg font-black text-[#111827]">Configurar metas</h2>
            <p className="text-xs text-[#64748b]">
              Carga metas en USD para sucursales, vendedores y Almundo.
            </p>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="flex h-9 w-9 items-center justify-center rounded-xl text-[#64748b] hover:bg-black/5 hover:text-[#111827]"
          >
            <X size={17} />
          </button>
        </div>

        <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_280px]">
          <main className="rounded-[24px] border border-black/10 bg-white p-4">
            <div className="grid gap-3 md:grid-cols-2">
              <div>
                <FieldLabel>Tipo de meta</FieldLabel>
                <NosturSelect value={draft.tipo} onChange={handleTipoChange} options={TIPO_CREATE_OPTIONS} />
              </div>

              <div>
                <FieldLabel>Período</FieldLabel>
                <div className="grid grid-cols-[1fr_90px] gap-2">
                  <NosturSelect
                    value={draft.mes}
                    onChange={(value) => setPeriodo(value, draft.anio)}
                    options={MONTH_NAMES.map((month, index) => ({
                      value: String(index + 1).padStart(2, "0"),
                      label: month
                    }))}
                  />

                  <TextInput
                    value={draft.anio}
                    onChange={(value) => setPeriodo(draft.mes, value.replace(/\D/g, "").slice(0, 4))}
                    placeholder="2026"
                    inputMode="numeric"
                  />
                </div>
              </div>

             <div>
  <FieldLabel>Desde</FieldLabel>
  <NosturDateInput
    value={draft.fecha_desde}
    onChange={(value) => setField("fecha_desde", value)}
  />
</div>

<div>
  <FieldLabel>Hasta</FieldLabel>
  <NosturDateInput
    value={draft.fecha_hasta}
    onChange={(value) => setField("fecha_hasta", value)}
  />
</div>

              {isSucursal ? (
                <div className="md:col-span-2">
                  <FieldLabel>Sucursal</FieldLabel>
                  <NosturSelect
                    value={draft.sucursal_id}
                    onChange={(value) => setField("sucursal_id", value)}
                    options={sucursalOptions}
                    placeholder="Seleccionar sucursal"
                  />
                </div>
              ) : null}

              {isVendedor ? (
                <>
                  <div>
                    <FieldLabel>Alcance</FieldLabel>
                    <NosturSelect
                      value={draft.alcance}
                      onChange={(value) => {
                        setDraft((current) => ({
                          ...current,
                          alcance: value as CreateMetaDraft["alcance"],
                          vendedor_id: ""
                        }));
                      }}
                      options={[
                        { value: "TODOS", label: "Todos los vendedores" },
                        { value: "ESPECIFICO", label: "Vendedor específico" }
                      ]}
                    />
                  </div>

                  <div>
                    <FieldLabel>Vendedor</FieldLabel>
                    <NosturSelect
                      value={draft.vendedor_id}
                      onChange={(value) => setField("vendedor_id", value)}
                      options={vendedorOptions}
                      placeholder={draft.alcance === "TODOS" ? "Aplica a todos" : "Seleccionar vendedor"}
                    />
                  </div>
                </>
              ) : null}

              {isWeekly || isAlmundo ? (
                <div className="md:col-span-2">
                  <FieldLabel>{isAlmundo ? "Meta facturación Almundo USD" : "Meta semanal USD"}</FieldLabel>
                  <TextInput
                    value={draft.meta_unica_usd}
                    onChange={(value) => setField("meta_unica_usd", value)}
                    placeholder="0,00"
                    inputMode="decimal"
                  />
                </div>
              ) : (
                <div className="grid gap-3 md:col-span-2 md:grid-cols-3">
                  <div>
                    <FieldLabel>Piso USD</FieldLabel>
                    <TextInput
                      value={draft.meta_piso_usd}
                      onChange={(value) => setField("meta_piso_usd", value)}
                      placeholder="0,00"
                      inputMode="decimal"
                    />
                  </div>

                  <div>
                    <FieldLabel>Medio USD</FieldLabel>
                    <TextInput
                      value={draft.meta_medio_usd}
                      onChange={(value) => setField("meta_medio_usd", value)}
                      placeholder="0,00"
                      inputMode="decimal"
                    />
                  </div>

                  <div>
                    <FieldLabel>Logrado USD</FieldLabel>
                    <TextInput
                      value={draft.meta_logrado_usd}
                      onChange={(value) => setField("meta_logrado_usd", value)}
                      placeholder="0,00"
                      inputMode="decimal"
                    />
                  </div>
                </div>
              )}

              {isMonthlySeller ? (
                <div className="grid gap-3 rounded-2xl border border-nostur-orange/20 bg-nostur-orange/10 p-3 md:col-span-2 md:grid-cols-3">
                  <div>
                    <FieldLabel>% Piso</FieldLabel>
                    <TextInput
                      value={draft.comision_piso_pct}
                      onChange={(value) => setField("comision_piso_pct", value)}
                      placeholder="8"
                      inputMode="decimal"
                    />
                  </div>

                  <div>
                    <FieldLabel>% Medio</FieldLabel>
                    <TextInput
                      value={draft.comision_medio_pct}
                      onChange={(value) => setField("comision_medio_pct", value)}
                      placeholder="10"
                      inputMode="decimal"
                    />
                  </div>

                  <div>
                    <FieldLabel>% Logrado</FieldLabel>
                    <TextInput
                      value={draft.comision_logrado_pct}
                      onChange={(value) => setField("comision_logrado_pct", value)}
                      placeholder="12"
                      inputMode="decimal"
                    />
                  </div>
                </div>
              ) : null}

              <div className="md:col-span-2">
                <FieldLabel>Observaciones</FieldLabel>
                <TextArea
                  value={draft.observaciones}
                  onChange={(value) => setField("observaciones", value)}
                  placeholder="Notas internas sobre esta meta..."
                />
              </div>
            </div>
          </main>

          <aside className="rounded-[24px] border border-black/10 bg-[#f8fafc] p-4">
            <h3 className="mb-3 text-sm font-black text-[#111827]">Resumen</h3>

            <div className="grid gap-3 text-xs">
              <div>
                <FieldLabel>Tipo</FieldLabel>
                <div className="font-black text-[#111827]">{getTipoLabel(draft.tipo)}</div>
                <div className="text-[#64748b]">{getBaseLabel(draft.tipo)}</div>
              </div>

              <div>
                <FieldLabel>Período</FieldLabel>
                <div className="font-black text-[#111827]">{getMonthYearLabel(draft.mes, draft.anio)}</div>
                <div className="text-[#64748b]">
                  {formatDate(draft.fecha_desde)} → {formatDate(draft.fecha_hasta)}
                </div>
              </div>

              <div>
                <FieldLabel>Aplica a</FieldLabel>
                <div className="font-black text-[#111827]">
                  {isSucursal
                    ? sucursalOptions.find((item) => item.value === draft.sucursal_id)?.label || "Seleccionar sucursal"
                    : draft.alcance === "TODOS"
                      ? "Todos los vendedores"
                      : vendedorOptions.find((item) => item.value === draft.vendedor_id)?.label || "Seleccionar vendedor"}
                </div>
              </div>

              <div className="rounded-2xl border border-black/10 bg-white p-3">
                <div className="text-[10px] font-black uppercase tracking-wide text-[#64748b]">
                  Importe principal
                </div>
                <div className="mt-1 text-lg font-black text-nostur-orange">
                  {isWeekly || isAlmundo
                    ? formatMoneyAR(parseMoney(draft.meta_unica_usd), "USD")
                    : formatMoneyAR(parseMoney(draft.meta_logrado_usd), "USD")}
                </div>
              </div>
            </div>
          </aside>
        </div>

        <div className="mt-5 flex justify-between gap-2">
          <button
            type="button"
            onClick={onClose}
            className="h-9 rounded-xl px-4 text-xs font-bold text-[#64748b] hover:bg-black/5 hover:text-[#111827]"
          >
            Cancelar
          </button>

          <button
            type="button"
            disabled={saving}
            onClick={submit}
            className="h-9 rounded-xl bg-nostur-orange px-5 text-xs font-black text-white shadow-sm hover:bg-nostur-orangeSoft disabled:opacity-50"
          >
            {saving ? "Guardando..." : "Crear meta"}
          </button>
        </div>
      </div>
    </div>
  );
}

function MetaSidePanel({
  selected,
  saving,
  onSave
}: {
  selected: MetaResumen | null;
  saving: boolean;
  onSave: (draft: MetaDraft) => Promise<void>;
}) {
  const [draft, setDraft] = useState<MetaDraft>(() => buildInitialDraft(selected));

  useEffect(() => {
    setDraft(buildInitialDraft(selected));
  }, [selected?.meta.id]);

  if (!selected) {
    return (
      <aside className="min-w-0 rounded-[24px] border border-black/10 bg-white/80 p-4 shadow-sm backdrop-blur">
        <div className="rounded-2xl border border-black/10 bg-[#f8fafc] p-5 text-center text-xs text-[#64748b]">
          Seleccioná una meta para ver o editar.
        </div>
      </aside>
    );
  }

  const meta = selected.meta;
  const isWeekly = meta.tipo === "VENDEDOR_SEMANAL";
  const isAlmundo = meta.tipo === "ALMUNDO_MENSUAL";
  const isMonthlySeller = meta.tipo === "VENDEDOR_MENSUAL";

  function setField<K extends keyof MetaDraft>(key: K, value: MetaDraft[K]) {
    setDraft((current) => ({ ...current, [key]: value }));
  }

  return (
    <aside className="min-w-0 rounded-[24px] border border-black/10 bg-white/80 p-4 shadow-sm backdrop-blur">
      <div className="mb-4 flex items-start justify-between gap-3">
        <div>
          <h2 className="text-sm font-black text-[#111827]">{getTipoLabel(meta.tipo)}</h2>
          <p className="mt-0.5 text-xs text-[#64748b]">
            {selected.sucursal?.nombre || getNombreCompleto(selected.vendedor)} · Configuración USD
          </p>
        </div>

        <StatusBadge type={getEstadoType(selected.estadoPeriodo)}>{selected.estadoPeriodo}</StatusBadge>
      </div>

      <div className="grid gap-4 text-xs">
        <div className="rounded-2xl border border-black/10 bg-[#f8fafc] p-3">
          <FieldLabel>Base de cálculo</FieldLabel>
          <div className="font-black text-[#111827]">{getBaseLabel(meta.tipo)}</div>
          <div className="mt-1 text-[#64748b]">
            Todas las metas se expresan en USD. Los importes en pesos se convertirán por tipo de cambio promedio diario.
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2">
          <div>
  <FieldLabel>Desde</FieldLabel>
  <NosturDateInput
    value={draft.fecha_desde}
    onChange={(value) => setField("fecha_desde", value)}
  />
</div>

<div>
  <FieldLabel>Hasta</FieldLabel>
  <NosturDateInput
    value={draft.fecha_hasta}
    onChange={(value) => setField("fecha_hasta", value)}
  />
</div>
        </div>

        {isWeekly || isAlmundo ? (
          <div>
            <FieldLabel>{isAlmundo ? "Meta facturación Almundo USD" : "Meta semanal USD"}</FieldLabel>
            <TextInput
              value={draft.meta_unica_usd}
              onChange={(value) => setField("meta_unica_usd", value)}
              placeholder="0,00"
              inputMode="decimal"
            />
          </div>
        ) : (
          <div className="grid grid-cols-3 gap-2">
            <div>
              <FieldLabel>Piso USD</FieldLabel>
              <TextInput
                value={draft.meta_piso_usd}
                onChange={(value) => setField("meta_piso_usd", value)}
                placeholder="0,00"
                inputMode="decimal"
              />
            </div>

            <div>
              <FieldLabel>Medio USD</FieldLabel>
              <TextInput
                value={draft.meta_medio_usd}
                onChange={(value) => setField("meta_medio_usd", value)}
                placeholder="0,00"
                inputMode="decimal"
              />
            </div>

            <div>
              <FieldLabel>Logrado USD</FieldLabel>
              <TextInput
                value={draft.meta_logrado_usd}
                onChange={(value) => setField("meta_logrado_usd", value)}
                placeholder="0,00"
                inputMode="decimal"
              />
            </div>
          </div>
        )}

        {isMonthlySeller ? (
          <div className="grid grid-cols-3 gap-2 rounded-2xl border border-nostur-orange/20 bg-nostur-orange/10 p-3">
            <div>
              <FieldLabel>% Piso</FieldLabel>
              <TextInput
                value={draft.comision_piso_pct}
                onChange={(value) => setField("comision_piso_pct", value)}
                placeholder="8"
                inputMode="decimal"
              />
            </div>

            <div>
              <FieldLabel>% Medio</FieldLabel>
              <TextInput
                value={draft.comision_medio_pct}
                onChange={(value) => setField("comision_medio_pct", value)}
                placeholder="10"
                inputMode="decimal"
              />
            </div>

            <div>
              <FieldLabel>% Logrado</FieldLabel>
              <TextInput
                value={draft.comision_logrado_pct}
                onChange={(value) => setField("comision_logrado_pct", value)}
                placeholder="12"
                inputMode="decimal"
              />
            </div>
          </div>
        ) : null}

        <div>
          <FieldLabel>Observaciones</FieldLabel>
          <TextArea
            value={draft.observaciones}
            onChange={(value) => setField("observaciones", value)}
            placeholder="Notas internas de la meta..."
          />
        </div>

        <button
          type="button"
          onClick={() => setField("activa", !draft.activa)}
          className={[
            "h-9 rounded-xl border px-4 text-xs font-black transition",
            draft.activa
              ? "border-green-200 bg-green-50 text-green-700"
              : "border-red-200 bg-red-50 text-red-700"
          ].join(" ")}
        >
          {draft.activa ? "Meta activa" : "Meta inactiva"}
        </button>

        <button
          type="button"
          disabled={saving}
          onClick={() => onSave(draft)}
          className="h-10 rounded-xl bg-nostur-orange px-4 text-xs font-black text-white shadow-sm hover:bg-nostur-orangeSoft disabled:opacity-50"
        >
          {saving ? "Guardando..." : "Guardar meta"}
        </button>
      </div>
    </aside>
  );
}

export function MetasPanel() {
  const loading = useMetasStore((state) => state.loading);
  const saving = useMetasStore((state) => state.saving);
  const error = useMetasStore((state) => state.error);
  const filters = useMetasStore((state) => state.filters);
  const catalogos = useMetasStore((state) => state.catalogos);
  const selectedMetaId = useMetasStore((state) => state.selectedMetaId);

  const loadMetas = useMetasStore((state) => state.loadMetas);
  const saveMeta = useMetasStore((state) => state.saveMeta);
  const setFilter = useMetasStore((state) => state.setFilter);
  const clearError = useMetasStore((state) => state.clearError);
  const selectMeta = useMetasStore((state) => state.selectMeta);
  const goToPreviousMonth = useMetasStore((state) => state.goToPreviousMonth);
  const goToNextMonth = useMetasStore((state) => state.goToNextMonth);
  const goToCurrentMonth = useMetasStore((state) => state.goToCurrentMonth);

  const getResumen = useMetasStore((state) => state.getResumen);
  const getSelectedResumen = useMetasStore((state) => state.getSelectedResumen);
  const getMetrics = useMetasStore((state) => state.getMetrics);

  const resumen = getResumen();
  const metrics = getMetrics();

  const [filtersOpen, setFiltersOpen] = useState(false);
  const [createModalOpen, setCreateModalOpen] = useState(false);
  const [toast, setToast] = useState<ToastState>(null);

  const selectedResumen = useMemo(
    () => getSelectedResumen(),
    [resumen, selectedMetaId, getSelectedResumen]
  );

  useEffect(() => {
    loadMetas();
  }, [loadMetas]);

  function showToast(message: string, type: "success" | "error" = "success") {
    setToast({ type, message });
    window.setTimeout(() => setToast(null), 3200);
  }

  function reloadAfterPeriodChange(callback: () => void) {
    callback();
    window.setTimeout(() => {
      loadMetas();
    }, 0);
  }

  async function handleSave(draft: MetaDraft) {
    if (!selectedResumen) return;

    const ok = await saveMeta(selectedResumen.meta, draft);

    if (ok) showToast("Meta guardada correctamente.");
  }

  const sucursalOptions: SelectOption[] = [
    { value: "todos", label: "Todas" },
    ...catalogos.sucursales.map((item) => ({
      value: item.id,
      label: item.nombre
    }))
  ];

  const vendedorOptions: SelectOption[] = [
    { value: "todos", label: "Todos" },
    { value: "general", label: "General / todos los vendedores" },
    ...catalogos.vendedores.map((item) => ({
      value: item.id,
      label: getNombreCompleto(item)
    }))
  ];

  return (
    <div className="h-full overflow-auto bg-[radial-gradient(circle_at_22%_10%,rgba(255,122,26,0.10),transparent_28%),radial-gradient(circle_at_78%_18%,rgba(90,120,190,0.13),transparent_30%),linear-gradient(135deg,#eef1f6,#e1e7f0_48%,#eef1f6)] px-6 py-5 text-[#1f2937]">
      <div className="mx-auto w-full max-w-[calc(100vw-110px)]">
        <div className="mb-2 flex flex-wrap items-center gap-2">
          <h1 className="text-xl font-black tracking-tight text-[#111827]">Metas</h1>
          <span className="rounded-xl bg-white/80 px-2 py-1 text-[10px] font-black uppercase tracking-wide text-[#64748b]">
            CONFIGURACIÓN
          </span>
          <span className="text-xs font-semibold text-[#64748b]">
            Objetivos en USD para vendedores, sucursales y Almundo
          </span>
        </div>

        {error ? (
          <div className="mb-4 flex items-start justify-between gap-3 rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-xs font-semibold text-red-700">
            <span>{error}</span>
            <button onClick={clearError} className="text-red-500 hover:text-red-700">
              <X size={14} />
            </button>
          </div>
        ) : null}

        <section className="relative z-[30] mb-4 rounded-[24px] border border-black/10 bg-white/55 p-3 shadow-sm backdrop-blur">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-2">
              <div className="flex h-9 overflow-hidden rounded-[16px] border border-black/10 bg-white/80 p-0.5 shadow-sm">
                <button
                  type="button"
                  onClick={() => reloadAfterPeriodChange(goToPreviousMonth)}
                  className="h-8 rounded-[13px] px-3 text-[11px] font-black text-[#334155] transition hover:bg-white"
                >
                  Mes anterior
                </button>

                <div className="flex h-8 min-w-[132px] items-center justify-center rounded-[13px] bg-[#111827] px-4 text-xs font-black text-white">
                  {getMonthYearLabel(filters.mes, filters.anio)}
                </div>

                <button
                  type="button"
                  onClick={() => reloadAfterPeriodChange(goToNextMonth)}
                  className="h-8 rounded-[13px] px-3 text-[11px] font-black text-[#334155] transition hover:bg-white"
                >
                  Mes siguiente
                </button>
              </div>

              <button
                type="button"
                onClick={() => reloadAfterPeriodChange(goToCurrentMonth)}
                className="h-8 rounded-[13px] bg-nostur-orange px-3 text-[11px] font-black text-white shadow-sm hover:bg-nostur-orangeSoft"
              >
                Este mes
              </button>
            </div>

            <div className="flex shrink-0 flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={loadMetas}
                disabled={loading}
                className="flex h-8 items-center gap-2 rounded-xl bg-white/80 px-3 text-[11px] font-black text-[#334155] shadow-sm hover:bg-white disabled:opacity-50"
              >
                <RefreshCcw size={13} strokeWidth={1.8} />
                Actualizar
              </button>

              <button
                type="button"
                onClick={() => setCreateModalOpen(true)}
                className="flex h-8 items-center gap-2 rounded-xl bg-nostur-orange px-3 text-[11px] font-black text-white shadow-sm hover:bg-nostur-orangeSoft"
              >
                <Plus size={13} strokeWidth={1.8} />
                Configurar metas
              </button>

              <button
                type="button"
                onClick={() => setFiltersOpen((current) => !current)}
                className="flex h-8 items-center gap-2 rounded-xl bg-white/80 px-3 text-[11px] font-black text-[#334155] shadow-sm hover:bg-white"
              >
                {filtersOpen ? "Ocultar" : "Mostrar"}
                <ChevronsUpDown size={14} strokeWidth={1.8} />
              </button>
            </div>
          </div>

          {filtersOpen ? (
            <>
              <div className="mt-4 grid gap-3 lg:grid-cols-[1fr_1fr_1fr_1fr]">
                <div>
                  <FieldLabel>Tipo</FieldLabel>
                  <NosturSelect
                    value={filters.tipo}
                    onChange={(value) => setFilter("tipo", value as typeof filters.tipo)}
                    options={TIPO_OPTIONS}
                  />
                </div>

                <div>
                  <FieldLabel>Sucursal</FieldLabel>
                  <NosturSelect
                    value={filters.sucursalId}
                    onChange={(value) => setFilter("sucursalId", value)}
                    options={sucursalOptions}
                  />
                </div>

                <div>
                  <FieldLabel>Vendedor</FieldLabel>
                  <NosturSelect
                    value={filters.vendedorId}
                    onChange={(value) => setFilter("vendedorId", value)}
                    options={vendedorOptions}
                  />
                </div>

                <div>
                  <FieldLabel>Estado</FieldLabel>
                  <NosturSelect
                    value={filters.estado}
                    onChange={(value) => setFilter("estado", value as typeof filters.estado)}
                    options={ESTADO_OPTIONS}
                  />
                </div>
              </div>

              <div className="mt-3 grid gap-3 lg:grid-cols-[minmax(0,1fr)_auto]">
                <div className="flex h-10 items-center gap-2 rounded-2xl border border-black/10 bg-white/80 px-3">
                  <Search size={15} className="shrink-0 text-[#64748b]" />
                  <input
                    value={filters.search}
                    onChange={(event) => setFilter("search", event.target.value)}
                    placeholder="Buscar por tipo, sucursal, vendedor, estado u observación..."
                    className="h-full min-w-0 flex-1 bg-transparent text-xs font-semibold outline-none placeholder:text-[#94a3b8]"
                  />
                </div>

                <button
                  type="button"
                  onClick={loadMetas}
                  className="h-10 rounded-2xl bg-white/80 px-4 text-xs font-black text-[#334155] shadow-sm hover:bg-white"
                >
                  Aplicar filtros
                </button>
              </div>
            </>
          ) : null}
        </section>

                <section className="relative z-0 mb-4 grid gap-3 md:grid-cols-3 xl:grid-cols-6">
          <MetricCard label="Metas" value={metrics.total} icon={Target} />
          <MetricCard label="Activas" value={metrics.activas} icon={CalendarClock} />
          <MetricCard label="Inactivas" value={metrics.inactivas} icon={X} />
          <MetricCard label="Vendedores" value={metrics.vendedor} icon={UsersRound} />
          <MetricCard label="Sucursales" value={metrics.sucursal} icon={Building2} />
          <MetricCard label="Almundo" value={metrics.almundo} icon={Trophy} />
        </section>

        <div className="relative z-0 grid gap-4 xl:grid-cols-[minmax(0,1fr)_400px]">
          <section className="min-w-0 rounded-[24px] border border-black/10 bg-white/70 p-4 shadow-sm backdrop-blur">
            <div className="mb-3 flex items-center justify-between gap-3">
              <div>
                <h2 className="text-sm font-black text-[#111827]">Listado de metas</h2>
                <p className="text-[11px] text-[#64748b]">
                  {loading ? "Cargando..." : `${resumen.length} metas configuradas`}
                </p>
              </div>

              <div className="rounded-xl bg-white/80 px-3 py-1.5 text-[10px] font-black uppercase tracking-wide text-[#64748b]">
                {getMonthYearLabel(filters.mes, filters.anio)}
              </div>
            </div>

            {loading ? (
              <div className="rounded-2xl border border-black/10 bg-[#f8fafc] p-5 text-center text-xs text-[#64748b]">
                Cargando metas...
              </div>
            ) : resumen.length === 0 ? (
              <div className="rounded-2xl border border-black/10 bg-[#f8fafc] p-5 text-center text-xs text-[#64748b]">
                No hay metas para los filtros seleccionados.
              </div>
            ) : (
              <div className="grid gap-2">
                {resumen.map((item) => {
                  const meta = item.meta;
                  const selected = selectedResumen?.meta.id === meta.id;
                  const isWeekly = meta.tipo === "VENDEDOR_SEMANAL";
                  const isMonthlySeller = meta.tipo === "VENDEDOR_MENSUAL";
                  const isAlmundo = meta.tipo === "ALMUNDO_MENSUAL";

                  const appliesTo = item.sucursal?.nombre || getNombreCompleto(item.vendedor);

                  return (
                    <button
                      key={meta.id}
                      type="button"
                      onClick={() => selectMeta(meta.id)}
                      className={[
                        "grid min-w-0 gap-3 rounded-2xl border p-3 text-left transition lg:grid-cols-[1.25fr_1fr_1.3fr_1fr_110px_60px]",
                        selected
                          ? "border-nostur-orange/50 bg-nostur-orange/10"
                          : "border-black/10 bg-[#f8fafc] hover:bg-white"
                      ].join(" ")}
                    >
                      <div className="min-w-0">
                        <div className="truncate text-xs font-black text-[#111827]">
                          {getTipoLabel(meta.tipo)}
                        </div>
                        <div className="truncate text-[11px] font-semibold text-[#64748b]">
                          {getBaseLabel(meta.tipo)}
                        </div>
                        <div className="truncate text-[10px] font-black text-nostur-orange">
                          USD
                        </div>
                      </div>

                      <div className="min-w-0">
                        <div className="truncate text-xs font-black text-[#111827]">
                          {appliesTo}
                        </div>
                        <div className="truncate text-[11px] text-[#64748b]">
                          {formatDate(meta.fecha_desde)} → {formatDate(meta.fecha_hasta)}
                        </div>
                        {meta.vendedor_id ? (
                          <div className="truncate text-[10px] font-bold text-[#94a3b8]">
                            Meta particular
                          </div>
                        ) : meta.tipo === "VENDEDOR_MENSUAL" || meta.tipo === "VENDEDOR_SEMANAL" ? (
                          <div className="truncate text-[10px] font-bold text-[#94a3b8]">
                            Aplica a todos
                          </div>
                        ) : null}
                      </div>

                      <div className="min-w-0">
                        {isWeekly || isAlmundo ? (
                          <>
                            <div className="text-xs font-black text-[#111827]">
                              {formatMoneyAR(meta.meta_unica_usd || meta.meta_logrado_usd, "USD")}
                            </div>
                            <div className="text-[11px] text-[#64748b]">
                              {isAlmundo ? "Meta facturación" : "Meta semanal única"}
                            </div>
                          </>
                        ) : (
                          <>
                            <div className="truncate text-xs font-black text-[#111827]">
                              P {formatMoneyAR(meta.meta_piso_usd, "USD")} · M{" "}
                              {formatMoneyAR(meta.meta_medio_usd, "USD")} · L{" "}
                              {formatMoneyAR(meta.meta_logrado_usd, "USD")}
                            </div>
                            <div className="text-[11px] text-[#64748b]">
                              Piso / Medio / Logrado
                            </div>
                          </>
                        )}
                      </div>

                      <div className="min-w-0">
                        {isMonthlySeller ? (
                          <>
                            <div className="text-xs font-black text-[#111827]">
                              {String(meta.comision_piso_pct).replace(".", ",")}% ·{" "}
                              {String(meta.comision_medio_pct).replace(".", ",")}% ·{" "}
                              {String(meta.comision_logrado_pct).replace(".", ",")}%
                            </div>
                            <div className="text-[11px] text-[#64748b]">
                              Comisión mensual
                            </div>
                          </>
                        ) : meta.tipo === "VENDEDOR_SEMANAL" ? (
                          <>
                            <div className="text-xs font-black text-[#111827]">
                              Sin comisión
                            </div>
                            <div className="text-[11px] text-[#64748b]">
                              Incentivo semanal
                            </div>
                          </>
                        ) : meta.tipo === "ALMUNDO_MENSUAL" ? (
                          <>
                            <div className="text-xs font-black text-[#111827]">
                              Almundo
                            </div>
                            <div className="text-[11px] text-[#64748b]">
                              Carritos únicamente
                            </div>
                          </>
                        ) : (
                          <>
                            <div className="text-xs font-black text-[#111827]">
                              Sucursal
                            </div>
                            <div className="text-[11px] text-[#64748b]">
                              Utilidad total
                            </div>
                          </>
                        )}
                      </div>

                      <div className="flex flex-wrap items-center gap-1">
                        <StatusBadge type={getEstadoType(item.estadoPeriodo)}>
                          {item.estadoPeriodo}
                        </StatusBadge>
                      </div>

                      <div className="flex items-center justify-end gap-1">
                        <IconButton
                          icon={Edit3}
                          label="Editar meta"
                          className="text-nostur-orange"
                          onClick={(event) => {
                            event.stopPropagation();
                            selectMeta(meta.id);
                          }}
                        />
                      </div>
                    </button>
                  );
                })}
              </div>
            )}
          </section>

          <MetaSidePanel selected={selectedResumen} saving={saving} onSave={handleSave} />
        </div>
      </div>

      <Toast toast={toast} onClose={() => setToast(null)} />

      {createModalOpen ? (
        <MetaCreateModal
          onClose={() => setCreateModalOpen(false)}
          onSaved={() => {
            setCreateModalOpen(false);
            showToast("Meta creada correctamente.");
          }}
        />
      ) : null}
    </div>
  );
}